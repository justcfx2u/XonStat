#!/bin/sh
find output -name "*.png" -exec rm {} \;

